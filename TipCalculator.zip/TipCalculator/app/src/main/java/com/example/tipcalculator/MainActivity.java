package com.example.tipcalculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    private EditText editTextBillAmount;
    private EditText editTextNumGuests;
    private TextView textViewTotalAmount;
    private TextView textViewTipAmount;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextBillAmount = findViewById(R.id.editTextbill_amt);
        editTextNumGuests = findViewById(R.id.editTextNumGuests);
        textViewTotalAmount = findViewById(R.id.textViewTotalAmount);
        textViewTipAmount = findViewById(R.id.textViewTipAmount);
    }
    public void calculateTip(View view) {
        double BillAmount = Double.parseDouble(editTextBillAmount.getText().toString());
        int NumGuests = Integer.parseInt(String.valueOf(editTextNumGuests.getText()));
        }
    }